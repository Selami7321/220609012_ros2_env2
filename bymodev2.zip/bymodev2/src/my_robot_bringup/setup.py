from setuptools import setup
import os
from glob import glob

package_name = 'my_robot_bringup'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
        (os.path.join('share', package_name, 'worlds'), glob('worlds/*.world')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='selami',
    maintainer_email='selamicetin721@gmail.com',
    description='Ball Chaser Bringup Package',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'ball_chaser = my_robot_bringup.ball_chaser:main',
            'ball_control = my_robot_bringup.ball_control:main',
        ],
    },
)




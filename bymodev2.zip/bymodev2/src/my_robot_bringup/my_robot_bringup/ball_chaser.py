#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge
import cv2
import numpy as np


class BallChaser(Node):
    def __init__(self):
        super().__init__('ball_chaser')
        
        # Initialize CV bridge
        self.bridge = CvBridge()
        
        # Create publisher for cmd_vel
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        
        # Create subscriber for camera image
        self.image_sub = self.create_subscription(
            Image,
            'camera/image_raw',
            self.image_callback,
            10
        )
        
        # Control parameters
        self.max_linear_velocity = 0.2
        self.max_angular_velocity = 0.5
        self.center_threshold = 30  # pixels from center
        self.min_ball_area = 50  # minimum ball area to consider valid
        
        # Initialize twist message
        self.twist = Twist()
        
        self.get_logger().info('Ball Chaser node started')
    
    def image_callback(self, msg):
        try:
            # Convert ROS image to OpenCV format
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            
            # Find white ball in the image
            ball_center = self.find_white_ball(cv_image)
            
            if ball_center is not None:
                # Calculate control commands based on ball position
                self.control_robot(ball_center, cv_image.shape[1])
            else:
                # No ball detected, stop the robot
                self.stop_robot()
                
        except Exception as e:
            self.get_logger().error(f'Error processing image: {str(e)}')
    
    def find_white_ball(self, image):
        """Find white ball in the image using color detection"""
        # Convert to HSV for better color detection
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        
        # Define range for white color in HSV (more restrictive)
        lower_white = np.array([0, 0, 180])
        upper_white = np.array([180, 30, 255])
        
        # Create mask for white color
        mask = cv2.inRange(hsv, lower_white, upper_white)
        
        # Apply morphological operations to clean up the mask
        kernel = np.ones((5,5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        
        # Find contours
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        if contours:
            # Filter contours by area (remove very small ones)
            valid_contours = [c for c in contours if cv2.contourArea(c) > self.min_ball_area]
            
            if valid_contours:
                # Find the largest contour (assuming it's the ball)
                largest_contour = max(valid_contours, key=cv2.contourArea)
                
                # Check if the contour is roughly circular (ball-like)
                area = cv2.contourArea(largest_contour)
                perimeter = cv2.arcLength(largest_contour, True)
                if perimeter > 0:
                    circularity = 4 * np.pi * area / (perimeter * perimeter)
                    if circularity > 0.3:  # More circular shapes
                        # Calculate center of the contour
                        M = cv2.moments(largest_contour)
                        if M["m00"] != 0:
                            cx = int(M["m10"] / M["m00"])
                            cy = int(M["m01"] / M["m00"])
                            return (cx, cy)
        
        return None
    
    def control_robot(self, ball_center, image_width):
        """Control robot based on ball position"""
        ball_x, ball_y = ball_center
        image_center_x = image_width // 2
        
        # Calculate error from center
        error_x = ball_x - image_center_x
        
        # Reset velocities
        self.twist.linear.x = 0.0
        self.twist.angular.z = 0.0
        
        if abs(error_x) > self.center_threshold:
            # Ball is not centered, rotate to center it
            if error_x > 0:
                # Ball is on the right, turn right
                self.twist.angular.z = -self.max_angular_velocity
                self.get_logger().info('Turning right to center ball')
            else:
                # Ball is on the left, turn left
                self.twist.angular.z = self.max_angular_velocity
                self.get_logger().info('Turning left to center ball')
        else:
            # Ball is centered, move forward
            self.twist.linear.x = self.max_linear_velocity
            self.get_logger().info('Moving forward - ball centered')
        
        # Publish the command
        self.cmd_vel_pub.publish(self.twist)
    
    def stop_robot(self):
        """Stop the robot when no ball is detected"""
        self.twist.linear.x = 0.0
        self.twist.angular.z = 0.0
        self.cmd_vel_pub.publish(self.twist)
        self.get_logger().info('Stopping - no ball detected')


def main(args=None):
    rclpy.init(args=args)
    
    ball_chaser = BallChaser()
    
    try:
        rclpy.spin(ball_chaser)
    except KeyboardInterrupt:
        pass
    finally:
        ball_chaser.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

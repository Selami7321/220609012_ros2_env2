#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import threading
import time


class BallDriver(Node):
    """ROS node that receives Twist messages and applies them to ball via Gazebo service"""
    
    def __init__(self):
        super().__init__('ball_driver')
        
        # Create subscriber for ball velocity commands
        self.cmd_sub = self.create_subscription(
            Twist,
            '/ball/cmd_vel',
            self.cmd_vel_callback,
            10
        )
        
        # Store the current velocity commands
        self.twist = Twist()
        self.get_logger().info('Ball driver node started - listening to /ball/cmd_vel')
        
        # Apply velocity continuously
        self.timer = self.create_timer(0.1, self.apply_velocity)
    
    def cmd_vel_callback(self, msg):
        """Callback for receiving velocity commands"""
        self.twist = msg
        self.get_logger().debug(f'Received velocity: linear.x={msg.linear.x}, linear.y={msg.linear.y}')
    
    def apply_velocity(self):
        """Apply velocity to the ball using Gazebo service"""
        if abs(self.twist.linear.x) > 0.001 or abs(self.twist.linear.y) > 0.001:
            try:
                # Use gz command to set model velocity
                import subprocess
                
                # Get current model pose
                cmd_get_pose = ['gz', 'model', '--name', 'ball', '--pose', '--print']
                result = subprocess.run(cmd_get_pose, capture_output=True, text=True, timeout=0.5)
                
                if result.returncode == 0:
                    # Calculate force based on velocity
                    # Force = mass * acceleration
                    force_x = self.twist.linear.x * 5.0  # Scale factor
                    force_y = self.twist.linear.y * 5.0  # Scale factor
                    
                    # Apply the force using Gazebo service (simplified approach)
                    # For now, just set the linear velocity directly
                    cmd = [
                        'gz', 'model', '--name', 'ball', '--cmd',
                        f'velocity --linear {force_x} {force_y} 0'
                    ]
                    
                    subprocess.run(cmd, timeout=0.5)
                    
            except Exception as e:
                self.get_logger().debug(f'Could not apply force: {str(e)}')


def main(args=None):
    rclpy.init(args=args)
    
    ball_driver = BallDriver()
    
    try:
        rclpy.spin(ball_driver)
    except KeyboardInterrupt:
        pass
    finally:
        ball_driver.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()


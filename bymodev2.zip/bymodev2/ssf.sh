#!/bin/bash

# SSF (Student Screen Face) Script for Robotik Ödev 2
# Ball Chaser Robot Navigasyon + GZ-Sim + SSF Hash

echo "=========================================="
echo "Robotik Dersi Ödev 2 - Ball Chaser Robot"
echo "Öğrenci: Selami Çetin (220609012)"
echo "=========================================="
echo ""
echo "SSF video kaydı başlatıldı!"
echo "Yüz görünürlüğü sağlanmıştır."
echo ""

################ HASH OLUŞTURMA ################
RAW_FILE="RAW.bin"

if [ -f "$RAW_FILE" ]; then
    SSF_HASH=$(sha256sum "$RAW_FILE" | awk '{print $1}')
    echo "SSF_HASH: $SSF_HASH" > SSF_HASH.txt
    echo "✅ SSF Hash oluşturuldu: $SSF_HASH"
else
    echo "❌ RAW.bin bulunamadı! Hash üretilemedi!"
fi

echo ""
echo "Sistem başlatılıyor..."
echo ""

################################################
# ROS2 environment yükle
source /opt/ros/humble/setup.bash
source install/setup.bash

echo "✅ ROS2 environment hazır!"
echo ""

################################################
# GZ Sim başlat
echo "🚀 GZ-Sim başlatılıyor..."
gnome-terminal -- bash -c "cd ~/Masaüstü/bymodev2 && gz sim bym_robot.sdf; exec bash"

sleep 5

################################################
# Bringup başlat
echo "🤖 Robot bringup başlatılıyor..."
gnome-terminal -- bash -c "ros2 launch my_robot_bringup bringup.launch.py; exec bash"

echo ""
echo "✅ Tüm sistem aktif!"
echo "👉 Sistem kapatmak için tüm terminalleri durdurmanız yeterlidir."


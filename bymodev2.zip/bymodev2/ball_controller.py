#!/usr/bin/env python3
"""
Manuel Top Hareket Ettirici - Q ile Çıkış
"""

import sys
import termios
import tty
from gz.transport13 import Node
from gz.msgs10.pose_pb2 import Pose
from gz.msgs10.boolean_pb2 import Boolean

class ManualBallMover:
    def __init__(self):
        self.node = Node()
        
        # Pozisyon
        self.x = 3.0
        self.y = 0.0
        self.z = 0.2
        
        # Adım boyutu
        self.step = 0.3
        
        print("═" * 60)
        print("  MANUEL TOP HAREKET ETTİRİCİ")
        print("═" * 60)
        print("  W/S: X ekseni (İleri/Geri)")
        print("  A/D: Y ekseni (Sol/Sağ)")
        print("  R: Resetle (3, 0, 0.2)")
        print("  Spacebar: Mevcut pozisyonu göster")
        print("  Q: Çıkış")
        print("═" * 60)
        print()

    def move_ball(self):
        """Topu yeni pozisyona taşı"""
        service = "/world/my_robot_world/set_pose"
        
        req = Pose()
        req.name = "ball"
        req.position.x = self.x
        req.position.y = self.y
        req.position.z = self.z
        req.orientation.w = 1.0
        req.orientation.x = 0.0
        req.orientation.y = 0.0
        req.orientation.z = 0.0
        
        timeout = 1000
        try:
            success, result = self.node.request(service, req, Pose, Boolean, timeout)
            if success and hasattr(result, 'data') and result.data:
                print(f"✓ Yeni pozisyon: ({self.x:.1f}, {self.y:.1f}, {self.z:.1f})")
                return True
            else:
                print(f"✗ Hareket başarısız")
                return False
        except Exception as e:
            print(f"✗ Hata: {e}")
            return False

    def get_key(self):
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            return sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)

    def run(self):
        print("Hazır! Tuşlara basın...\n")
        try:
            while True:
                k = self.get_key().lower()
                
                if k == 'w':
                    self.x += self.step
                    print(f"→ İleri (X+)", end=" ")
                    self.move_ball()
                elif k == 's':
                    self.x -= self.step
                    print(f"← Geri (X-)", end=" ")
                    self.move_ball()
                elif k == 'a':
                    self.y += self.step
                    print(f"↑ Sol (Y+)", end=" ")
                    self.move_ball()
                elif k == 'd':
                    self.y -= self.step
                    print(f"↓ Sağ (Y-)", end=" ")
                    self.move_ball()
                elif k == 'r':
                    self.x, self.y, self.z = 3.0, 0.0, 0.2
                    print("↻ Reset", end=" ")
                    self.move_ball()
                elif k == ' ':
                    print(f"📍 Pozisyon: ({self.x:.1f}, {self.y:.1f}, {self.z:.1f})")
                elif k == 'q':
                    print("\n\nÇıkış...")
                    break
                    
        except KeyboardInterrupt:
            print("\n\nDurduruldu.")

if __name__ == "__main__":
    mover = ManualBallMover()
    mover.run()

#!/bin/bash

echo "Ball Chaser Robot Test Script"
echo "============================="

# Check if ROS 2 is sourced
if [ -z "$ROS_DISTRO" ]; then
    echo "Error: ROS 2 environment not sourced!"
    echo "Please run: source /opt/ros/humble/setup.bash"
    exit 1
fi

echo "ROS 2 Distribution: $ROS_DISTRO"

# Source the workspace
echo "Sourcing workspace..."
source install/setup.bash

# Check if packages are built
echo "Checking packages..."
if ! ros2 pkg list | grep -q "my_robot_bringup"; then
    echo "Error: my_robot_bringup package not found!"
    echo "Please run: colcon build"
    exit 1
fi

echo "Package found: my_robot_bringup"

# Check if launch file exists
if [ ! -f "my_robot_bringup/launch/bringup.launch.py" ]; then
    echo "Error: Launch file not found!"
    exit 1
fi

echo "Launch file found: bringup.launch.py"

# Check if URDF file exists
if [ ! -f "my_robot.urdf" ]; then
    echo "Error: URDF file not found!"
    exit 1
fi

echo "URDF file found: my_robot.urdf"

# Check if ball chaser script exists and is executable
if [ ! -f "my_robot_bringup/scripts/ball_chaser.py" ]; then
    echo "Error: Ball chaser script not found!"
    exit 1
fi

if [ ! -x "my_robot_bringup/scripts/ball_chaser.py" ]; then
    echo "Making ball_chaser.py executable..."
    chmod +x my_robot_bringup/scripts/ball_chaser.py
fi

echo "Ball chaser script found and executable"

# Check dependencies
echo "Checking dependencies..."
python3 -c "import cv2, rclpy, sensor_msgs, geometry_msgs" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "Python dependencies OK"
else
    echo "Warning: Some Python dependencies might be missing"
fi

echo ""
echo "All checks passed! You can now run:"
echo "ros2 launch my_robot_bringup bringup.launch.py"
echo ""
echo "Make sure to run ssf.sh in another terminal first!"


#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import sys
import termios
import tty

class BallControl(Node):
    def __init__(self):
        super().__init__('ball_control')
        self.ball_cmd_pub = self.create_publisher(Twist, '/ball/cmd_vel', 10)

    def get_key(self):
        settings = termios.tcgetattr(sys.stdin)
        try:
            tty.setraw(sys.stdin.fileno())
            key = sys.stdin.read(1)
        finally:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        return key

    def run(self):
        twist = Twist()
        print("Top Kontrol: W A S D ile hareket, Q ile çıkış!")
        print("W: İleri, S: Geri, A: Sol, D: Sağ")

        while rclpy.ok():
            key = self.get_key()

            twist.linear.x = 0.0
            twist.linear.y = 0.0
            twist.angular.z = 0.0

            if key == 'w':
                twist.linear.x = 0.3
                print("İleri")
            elif key == 's':
                twist.linear.x = -0.3
                print("Geri")
            elif key == 'a':
                twist.linear.y = 0.3
                print("Sol")
            elif key == 'd':
                twist.linear.y = -0.3
                print("Sağ")
            elif key == 'q':
                print("Çıkılıyor...")
                break

            self.ball_cmd_pub.publish(twist)

def main():
    rclpy.init()
    node = BallControl()
    try:
        node.run()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()


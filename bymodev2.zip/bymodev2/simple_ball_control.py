#!/usr/bin/env python3
"""
Basit Top Kontrol - Planar Move ile
"""

import sys
import termios
import tty
from gz.transport13 import Node
from gz.msgs10.twist_pb2 import Twist

class SimpleBallController:
    def __init__(self):
        self.node = Node()
        self.topic = "/model/ball/cmd_vel"
        self.pub = self.node.advertise(self.topic, Twist)
        self.speed = 1.0
        
        print("═" * 50)
        print("  TOP KONTROL - Basit Mod")
        print("═" * 50)
        print("  W: İleri    S: Geri")
        print("  A: Sol      D: Sağ")
        print("  Q: Dur      ESC: Çıkış")
        print("═" * 50)
        print(f"\n✓ Topic: {self.topic}")
        print("✓ Tuşa basılı tutun!\n")

    def send_cmd(self, x, y, a=0):
        msg = Twist()
        msg.linear.x = x
        msg.linear.y = y
        msg.angular.z = a
        self.pub.publish(msg)

    def get_key(self):
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            return sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)

    def run(self):
        try:
            while True:
                k = self.get_key().lower()
                
                if k == 'w':
                    print("→ İleri", end="\r")
                    self.send_cmd(self.speed, 0)
                elif k == 's':
                    print("← Geri ", end="\r")
                    self.send_cmd(-self.speed, 0)
                elif k == 'a':
                    print("↑ Sol  ", end="\r")
                    self.send_cmd(0, self.speed)
                elif k == 'd':
                    print("↓ Sağ  ", end="\r")
                    self.send_cmd(0, -self.speed)
                elif k == 'q':
                    print("■ Dur  ", end="\r")
                    self.send_cmd(0, 0)
                elif k == '\x1b':
                    print("\n\nÇıkış...")
                    self.send_cmd(0, 0)
                    break
                    
        except KeyboardInterrupt:
            print("\n\nDurduruldu.")
            self.send_cmd(0, 0)

if __name__ == "__main__":
    SimpleBallController().run()

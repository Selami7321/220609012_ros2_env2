#!/usr/bin/env python3
"""
Robot Top Takip Scripti - Q ile Tam Durdurma
"""

import cv2
import numpy as np
from gz.transport13 import Node
from gz.msgs10.twist_pb2 import Twist
from gz.msgs10.image_pb2 import Image
import select
import sys
import termios
import tty
import time

class BallChaserRobot:
    def __init__(self):
        self.node = Node()
        
        # Robotun hız komutu için publisher
        self.cmd_topic = "/model/ball_chaser_robot/cmd_vel"
        self.pub = self.node.advertise(self.cmd_topic, Twist)
        
        # Kamera görüntüsü için subscriber
        self.img_topic = "/camera_sensor/image"
        if not self.node.subscribe(Image, self.img_topic, self.image_callback):
            print("HATA: Kamera topic'ine abone olunamadı!")
            print(f"Topic: {self.img_topic}")
        
        # Kontrol parametreleri
        self.max_linear_speed = 0.8
        self.min_linear_speed = 0.1
        self.max_angular_speed = 1.2
        
        self.image_width = 640
        self.image_height = 480
        self.center_threshold = 60
        
        # Mesafe kontrolü için
        self.min_ball_area = 500
        self.max_ball_area = 30000
        self.target_ball_area = 8000
        
        self.frame_count = 0
        self.last_seen_x = None
        self.no_ball_counter = 0
        self.running = True
        self.stopped = False  # Yeni: Robot durduruldu mu?

        print("=" * 60)
        print("  ROBOT TOP TAKİP SİSTEMİ")
        print("=" * 60)
        print(f"✓ Komut topic'i: {self.cmd_topic}")
        print(f"✓ Kamera topic'i: {self.img_topic}")
        print("✓ Q tuşu ile robot TAMAMEN DURDURULUR")
        print("=" * 60)
        print("\n🎯 Robot topu aktif olarak takip ediyor...\n")

    def image_callback(self, msg):
        """Kamera görüntüsünü işle ve topu takip et"""
        # Eğer robot durdurulduysa hiçbir şey yapma
        if self.stopped:
            return
            
        if not self.running:
            return
            
        self.frame_count += 1
        
        try:
            # Görüntüyü numpy array'e çevir
            img_data = np.frombuffer(msg.data, dtype=np.uint8)
            img = img_data.reshape((msg.height, msg.width, 3))
            
            # BGR formatına çevir (OpenCV için)
            img_bgr = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            
            # BEYAZ renk tespiti için HSV'ye çevir
            hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
            
            # BEYAZ renk için maske oluştur
            lower_white = np.array([0, 0, 200])
            upper_white = np.array([180, 30, 255])
            mask = cv2.inRange(hsv, lower_white, upper_white)
            
            # Morfolojik işlemler - gürültüyü azalt
            kernel = np.ones((5,5), np.uint8)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
            
            # Konturları bul
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            if contours:
                # En büyük konturu bul (top olmalı)
                largest_contour = max(contours, key=cv2.contourArea)
                area = cv2.contourArea(largest_contour)
                
                # Kontur alanı yeterince büyükse
                if area > 300:
                    # Topun merkezini bul
                    M = cv2.moments(largest_contour)
                    if M["m00"] != 0:
                        cx = int(M["m10"] / M["m00"])
                        cy = int(M["m01"] / M["m00"])
                        
                        # Debug bilgisi (her 30 frame'de bir)
                        if self.frame_count % 30 == 0:
                            print(f"🎯 Top bulundu! Pozisyon: ({cx}, {cy}), Alan: {area:.0f}")
                        
                        # Topu takip et
                        self.chase_ball(cx, cy, area)
                        self.last_seen_x = cx
                        self.no_ball_counter = 0
                        return
            
            # Top görünmüyorsa
            self.no_ball_counter += 1
            
            if self.no_ball_counter > 5:
                if self.no_ball_counter % 20 == 1:
                    print("⚠️  Top görünmüyor - Arıyor...")
                self.search_ball()
            
        except Exception as e:
            if self.frame_count % 100 == 0:
                print(f"⚠️  Görüntü işleme hatası: {e}")

    def chase_ball(self, ball_x, ball_y, ball_area):
        """Topu aktif olarak takip et"""
        # Eğer robot durdurulduysa hiçbir şey yapma
        if self.stopped:
            return
            
        msg = Twist()
        
        # Görüntü merkezine göre topun konumu
        image_center_x = self.image_width / 2
        error_x = ball_x - image_center_x
        
        # Normalized error (-1 ile 1 arası)
        normalized_error = error_x / (self.image_width / 2)
        
        # Mesafe tahmini (alan bazlı)
        if ball_area < self.min_ball_area:
            distance_factor = 1.0  # Uzak - hızlı git
        elif ball_area > self.max_ball_area:
            distance_factor = 0.1  # Çok yakın - çok yavaşla
        else:
            # Lineer mesafe faktörü
            distance_factor = (ball_area - self.min_ball_area) / (self.target_ball_area - self.min_ball_area)
            distance_factor = max(0.2, min(1.0, distance_factor))
        
        # Top merkeze yakın mı?
        if abs(error_x) < self.center_threshold:
            # MERKEZDEYSE - Düz ileri git
            msg.linear.x = self.max_linear_speed * distance_factor
            msg.angular.z = normalized_error * 0.5  # Hafif düzeltme
            
            if self.frame_count % 30 == 0:
                status = "UZAK" if distance_factor > 0.7 else "YAKIN" if distance_factor < 0.3 else "NORMAL"
                print(f"➡️  İLERİ! Hız: {msg.linear.x:.2f} m/s ({status})")
        else:
            # MERKEZ DIŞINDA - Önce dön, sonra ilerle
            msg.angular.z = -normalized_error * self.max_angular_speed
            
            # Sadece hafif hata varsa yavaş ilerle
            if abs(normalized_error) < 0.3:
                msg.linear.x = self.min_linear_speed * distance_factor
            else:
                msg.linear.x = 0.0  # Büyük hata varsa sadece dön
            
            direction = "SOL" if error_x > 0 else "SAĞ"
            if self.frame_count % 20 == 0:
                print(f"🔄 DÖNÜYOR ({direction}) - Açısal: {msg.angular.z:.2f} rad/s")
        
        self.pub.publish(msg)

    def search_ball(self):
        """Top kaybolduğunda ara"""
        # Eğer robot durdurulduysa hiçbir şey yapma
        if self.stopped:
            return
            
        msg = Twist()
        
        if self.last_seen_x is not None:
            # Son görülen yönde dön
            if self.last_seen_x > self.image_width / 2:
                msg.angular.z = -0.3  # Sola dön
            else:
                msg.angular.z = 0.3   # Sağa dön
            msg.linear.x = 0.1  # Yavaşça ilerle
        else:
            # Yavaşça sağa dön
            msg.angular.z = 0.4
            msg.linear.x = 0.0
        
        self.pub.publish(msg)

    def stop_robot_completely(self):
        """Robotu TAMAMEN durdur ve bir daha hareket etmesin"""
        msg = Twist()
        msg.linear.x = 0.0
        msg.angular.z = 0.0
        self.pub.publish(msg)
        
        # Robotu tamamen durdur - bir daha hareket etmeyecek
        self.stopped = True
        self.running = False
        
        print("⏹️  Robot TAMAMEN durduruldu!")
        print("⏹️  Artık hareket ETMEYECEK!")
        print("⏹️  Programı kapatmak için Ctrl+C'ye basın")

    def run(self):
        """Ana döngü - Q tuşu ile TAM DURDURMA"""
        print("✅ Robot çalışıyor... (Q tuşu ile TAMAMEN DURDUR)\n")
        
        # Terminali non-blocking mode'a al
        old_settings = termios.tcgetattr(sys.stdin)
        try:
            tty.setcbreak(sys.stdin.fileno())
            
            while self.running:
                # Q tuşu kontrolü
                if select.select([sys.stdin], [], [], 0.1)[0]:
                    key = sys.stdin.read(1)
                    if key == 'q' or key == 'Q':
                        print("\n\n⏹️  Q tuşuna basıldı - Robot TAMAMEN durduruluyor...")
                        self.stop_robot_completely()
                        # Durdurulduktan sonra da Q'ya basılırsa çık
                        break
                
                # Eğer robot durdurulduysa, sadece Q tuşunu dinlemeye devam et
                if self.stopped:
                    if select.select([sys.stdin], [], [], 0.1)[0]:
                        key = sys.stdin.read(1)
                        if key == 'q' or key == 'Q':
                            print("\n\nÇıkılıyor...")
                            break
                    time.sleep(0.1)
                
        except KeyboardInterrupt:
            print("\n\n⏹️  Ctrl+C - Sistem kapatılıyor...")
            self.stop_robot_completely()
        finally:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
            # Çıkışta da robotu durdur
            if not self.stopped:
                self.stop_robot_completely()

if __name__ == "__main__":
    robot = BallChaserRobot()
    robot.run()


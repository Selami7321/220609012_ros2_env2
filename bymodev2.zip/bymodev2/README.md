# Ball Chaser Robot Project

Bu proje, Gazebo Harmonic ortamında diferansiyel tahrikli bir robot ile beyaz küreyi takip eden bir Ball Chaser sistemi içerir.

## Proje Yapısı

```
bymodev2/
├── my_robot.urdf                    # Robot URDF modeli
├── bym_robot.sdf                    # Gazebo SDF dünyası (orijinal)
└── my_robot_bringup/                 # ROS 2 paketi
    ├── package.xml
    ├── CMakeLists.txt
    ├── launch/
    │   └── bringup.launch.py         # Ana launch dosyası
    ├── config/
    │   └── robot.rviz               # RViz konfigürasyonu
    ├── worlds/
    │   └── ball_chaser_world.sdf    # Gazebo dünyası
    └── scripts/
        └── ball_chaser.py           # Ball Chaser düğümü
```

## Robot Özellikleri

### Fiziksel Bileşenler
- **Chassis**: Ana gövde (0.5m x 0.3m x 0.1m)
- **Left Wheel**: Sol tahrikli tekerlek (continuous joint)
- **Right Wheel**: Sağ tahrikli tekerlek (continuous joint)
- **Caster Wheel**: Serbest teker (fixed joint)
- **Camera**: Kamera sensörü (640x480, 30 FPS)

### TF Yapısı
```
world
└── odom
    └── base_link
        ├── left_wheel_link
        ├── right_wheel_link
        ├── caster_link
        └── camera_link
```

## Kurulum ve Çalıştırma

### Gereksinimler
- ROS 2 Humble
- Gazebo Harmonic
- Python 3
- OpenCV (cv_bridge)
- RViz2

### Paket Kurulumu
```bash
cd /home/selamicetin/Masaüstü/bymodev2
colcon build --packages-select my_robot_bringup
source install/setup.bash
```

### Çalıştırma
```bash
# Terminal 1: SSF betiğini çalıştır
./ssf.sh

# Terminal 2: Ana launch dosyasını başlat
ros2 launch my_robot_bringup bringup.launch.py
```

## Ball Chaser Algoritması

### Girdi
- `/camera/image_raw` (sensor_msgs/Image)

### Çıktı
- `/cmd_vel` (geometry_msgs/Twist)

### Davranış
1. **Top Sağda/Solda**: Robot topu merkeze almak için döner
2. **Top Merkezde**: Robot ileri hareket eder
3. **Top Görünmüyor**: Robot durur (linear=0, angular=0)

### Parametreler
- `max_linear_velocity`: 0.3 m/s
- `max_angular_velocity`: 0.8 rad/s
- `center_threshold`: 50 piksel

## Video Senaryosu

1. SSF betiği çalıştırılır (yüz görünür)
2. `ros2 launch my_robot_bringup bringup.launch.py` komutu çalıştırılır
3. Sistem otomatik olarak başlatır:
   - Gazebo dünyası (robot + beyaz küre)
   - ROS-Gazebo köprüleri
   - robot_state_publisher ve joint_state_publisher
   - RViz (robot modeli ve kamera görüntüsü)
   - TF frames PDF çıktısı
   - Ball Chaser düğümü

## Teknik Detaylar

### Gazebo Pluginleri
- `libgazebo_ros_diff_drive.so`: Diferansiyel tahrik kontrolü
- `libgazebo_ros_camera.so`: Kamera sensörü

### ROS 2 Düğümleri
- `robot_state_publisher`: URDF'den TF yayını
- `joint_state_publisher`: Joint durumu yayını
- `ball_chaser`: Ana kontrol düğümü
- `ros_gz_bridge`: Gazebo-ROS köprüsü

### Konu Başlıkları
- `/cmd_vel`: Robot hız komutları
- `/camera/image_raw`: Kamera görüntüsü
- `/odom`: Odometri bilgisi
- `/tf`: Transform bilgileri

## Sorun Giderme

### Yaygın Sorunlar
1. **Kamera görüntüsü gelmiyor**: `ros_gz_bridge` köprüsünü kontrol edin
2. **Robot hareket etmiyor**: `/cmd_vel` konusunu kontrol edin
3. **TF hataları**: `robot_state_publisher` çalışıyor mu kontrol edin

### Debug Komutları
```bash
# Konu başlıklarını listele
ros2 topic list

# Kamera görüntüsünü kontrol et
ros2 topic echo /camera/image_raw --once

# Robot durumunu kontrol et
ros2 topic echo /cmd_vel

# TF ağacını görüntüle
ros2 run tf2_tools view_frames
```

## Lisans

Bu proje eğitim amaçlı geliştirilmiştir.

## İletişim

Proje ile ilgili sorularınız için GitHub Issues kullanabilirsiniz.

